/*
 * Set Locale
 */
wp.i18n.setLocaleData( { '': {} }, 'contact-widgets' );
