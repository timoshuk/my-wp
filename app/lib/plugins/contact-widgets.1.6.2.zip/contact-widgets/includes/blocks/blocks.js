// Locale
import './i18n.js';

// Import Blocks
import './contact/js/contact-block.js';
import './social/js/social-block.js';
